#include <stdint.h>

extern int main(void);
extern uint32_t _estack;
extern uint32_t _sdata, _edata, _sidata;
extern uint32_t _sbss, _ebss;

void Reset_Handler(void);
void Default_Handler(void);

// 声明 USB 中断处理函数
extern void USB_LP_CAN1_RX0_IRQHandler(void);

// 向量表，确保 USB_LP_CAN1_RX0_IRQHandler 放在了对应位置 (0xA0偏移处)
__attribute__((section(".isr_vector"), used))
void (*const g_vectors[])(void) = {
    (void (*)(void))&_estack,
    Reset_Handler,
    Default_Handler, // NMI
    Default_Handler, // HardFault
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, // SVCall
    Default_Handler, Default_Handler, // Debug, PendSV
    Default_Handler, // SysTick
    // 外部中断开始
    Default_Handler, Default_Handler, Default_Handler, Default_Handler, // EXTI0-3
    Default_Handler, Default_Handler, Default_Handler, Default_Handler, // EXTI4-7
    Default_Handler, Default_Handler, Default_Handler, Default_Handler, // EXTI8-11
    Default_Handler, Default_Handler, Default_Handler, Default_Handler, // EXTI12-15
    // ADC, CAN, USB 等等
    Default_Handler, Default_Handler, Default_Handler, Default_Handler, 
    USB_LP_CAN1_RX0_IRQHandler, // <-- USB 中断！
    Default_Handler, Default_Handler, Default_Handler, Default_Handler, Default_Handler
};

void Reset_Handler(void) {
    uint32_t* src = &_sidata;
    uint32_t* dst = &_sdata;
    while (dst < &_edata) *dst++ = *src++;
    dst = &_sbss;
    while (dst < &_ebss) *dst++ = 0;
    main();
    while (1) {}
}

void Default_Handler(void) {
    *(volatile uint32_t*)0x40021018 |= (1 << 4); // 开启 GPIOC 时钟
    *(volatile uint32_t*)0x40011004 &= ~(0x0F << 20); // 配置 PC13
    *(volatile uint32_t*)0x40011004 |=  (0x02 << 20);
    
    while (1) {
        // 极速闪烁（频率极快），代表触发了 HardFault
        *(volatile uint32_t*)0x40011010 = (1 << (13 + 16)); // 灭
        for(volatile int i=0; i<10000; i++);
        *(volatile uint32_t*)0x40011010 = (1 << 13); // 亮
        for(volatile int i=0; i<10000; i++);
    }
}