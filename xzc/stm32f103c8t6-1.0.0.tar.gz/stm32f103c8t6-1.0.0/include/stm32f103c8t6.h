#pragma once
#include <stdint.h>
#include "stm32f1xx.h"

void stm32f103c8t6_init(void);
