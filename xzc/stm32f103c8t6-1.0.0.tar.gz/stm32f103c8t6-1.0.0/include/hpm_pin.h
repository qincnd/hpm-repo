#pragma once

void hpm_pin_PA4_init(void);
void hpm_pin_PA4_write(int level);
int  hpm_pin_PA4_read(void);

void hpm_pin_PA5_init(void);
void hpm_pin_PA5_write(int level);
int  hpm_pin_PA5_read(void);

void hpm_pin_PA6_init(void);
void hpm_pin_PA6_write(int level);
int  hpm_pin_PA6_read(void);

void hpm_pin_PA7_init(void);
void hpm_pin_PA7_write(int level);
int  hpm_pin_PA7_read(void);

void hpm_pin_PB0_init(void);
void hpm_pin_PB0_write(int level);
int  hpm_pin_PB0_read(void);
