#pragma once
#include <stdint.h>
#include "stm32f103c8t6_usb_cdc.h"

// 缓冲区大小
#define CDC_RX_BUF_SIZE  64
#define CDC_TX_BUF_SIZE  64

// CDC 状态变量
extern volatile uint8_t CDC_readByteCount;
extern volatile uint8_t CDC_writeBusyFlag;
extern volatile uint8_t CDC_controlLineState;

// CDC 行编码
typedef struct _CDC_LINE_CODING_TYPE {
    uint32_t baudrate;
    uint8_t  stopbits;
    uint8_t  parity;
    uint8_t  databits;
} CDC_LINE_CODING_TYPE, *PCDC_LINE_CODING_TYPE;

extern CDC_LINE_CODING_TYPE CDC_lineCoding;

// CDC 函数
void CDC_init(void);
void CDC_flush(void);
char CDC_read(void);
void CDC_write(char c);

#define CDC_available()  (CDC_readByteCount)
#define CDC_ready()      (!CDC_writeBusyFlag)

// CDC 端点回调（由 usb_handler.c 调用）
void CDC_EP_init(void);
void CDC_EP2_OUT(void);
void CDC_EP3_IN(void);

// CDC 类请求处理
uint8_t CDC_control(void);