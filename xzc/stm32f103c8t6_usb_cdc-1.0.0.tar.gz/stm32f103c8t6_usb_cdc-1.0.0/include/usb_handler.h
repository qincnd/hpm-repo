#pragma once
#include <stdint.h>
#include "usb_descr.h"

// ST 库中断入口
void USB_Istr(void);

// USB 中断服务函数（STM32F103 的 USB 低优先级中断）
void USB_LP_CAN1_RX0_IRQHandler(void);

// 端点回调（ST 库 usb_istr.c 会调用这些）
void EP1_IN_Callback(void);
void EP2_OUT_Callback(void);
void EP3_IN_Callback(void);

// SET_CONFIGURATION 时由 ST 库调用
void USB_init_endpoints(void);

// USB 复位回调
void USB_reset_handler(void);