#include "usb_lib.h"

// 逐字节安全拷贝，强制 16 位读写，彻底杜绝 M3 的非对齐异常
void UserToPMABufferCopy(uint8_t *pbUsrBuf, uint16_t wPMABufAddr, uint16_t wNBytes)
{
    uint32_t n = (wNBytes + 1) >> 1;
    uint16_t *pdwVal = (uint16_t *)(0x40006000 + wPMABufAddr * 2); // 物理 PMA 基地址
    uint8_t *pbBuf = pbUsrBuf;

    for (uint32_t i = n; i != 0; i--)
    {
        uint16_t temp = 0;
        temp = (uint16_t)(*pbBuf++);
        if (i > 1 || (wNBytes % 2) != 0) {
            temp |= ((uint16_t)(*pbBuf++) << 8);
        }
        *pdwVal++ = temp;
    }
}

void PMAToUserBufferCopy(uint8_t *pbUsrBuf, uint16_t wPMABufAddr, uint16_t wNBytes)
{
    uint32_t n = (wNBytes + 1) >> 1;
    uint16_t *pdwVal = (uint16_t *)(0x40006000 + wPMABufAddr * 2);
    uint8_t *pbBuf = pbUsrBuf;

    for (uint32_t i = n; i != 0; i--)
    {
        uint16_t temp = *pdwVal++;
        *pbBuf++ = (uint8_t)(temp & 0xFF);
        if (i > 1 || (wNBytes % 2) != 0) {
            *pbBuf++ = (uint8_t)((temp >> 8) & 0xFF);
        }
    }
}