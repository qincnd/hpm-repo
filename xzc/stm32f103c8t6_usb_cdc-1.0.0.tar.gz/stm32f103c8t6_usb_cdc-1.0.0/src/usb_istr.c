#include "usb_lib.h"
#include "usb_conf.h"
#include "usb_istr.h"
#include "usb_pwr.h"

volatile uint16_t wIstr;
void (*pEpInt_IN[7])(void) = { NOP_Process, NOP_Process, NOP_Process, NOP_Process, NOP_Process, NOP_Process, NOP_Process };
void (*pEpInt_OUT[7])(void) = { NOP_Process, NOP_Process, NOP_Process, NOP_Process, NOP_Process, NOP_Process, NOP_Process };

void USB_Istr(void) {
    wIstr = _GetISTR();
    if (wIstr & ISTR_RESET) { _SetISTR((uint16_t)CLR_RESET); Device_Property.Reset(); }
    if (wIstr & ISTR_CTR) { CTR_LP(); }
    if (wIstr & ISTR_WKUP) { _SetISTR((uint16_t)CLR_WKUP); Resume(RESUME_EXTERNAL); }
    if (wIstr & ISTR_SUSP) { if (fSuspendEnabled) Suspend(); else Resume(RESUME_LATER); _SetISTR((uint16_t)CLR_SUSP); }
}