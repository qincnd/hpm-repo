#include "usb_lib.h"
#include "usb_conf.h"
#include "usb_prop.h"
#include "usb_descr.h"
#include "usb_pwr.h"

uint8_t Request = 0;
LINE_CODING linecoding = { 115200, 0x00, 0x00, 0x08 };
DEVICE Device_Table = { EP_NUM, 1 };

DEVICE_PROP Device_Property = {
    Virtual_Com_Port_init, Virtual_Com_Port_Reset, Virtual_Com_Port_Status_In,
    Virtual_Com_Port_Status_Out, Virtual_Com_Port_Data_Setup, Virtual_Com_Port_NoData_Setup,
    Virtual_Com_Port_Get_Interface_Setting, Virtual_Com_Port_GetDeviceDescriptor,
    Virtual_Com_Port_GetConfigDescriptor, Virtual_Com_Port_GetStringDescriptor,
    0, 0x08 // MaxPacketSize0 = 8 (最稳妥)
};

USER_STANDARD_REQUESTS User_Standard_Requests = {
    Virtual_Com_Port_GetConfiguration, Virtual_Com_Port_SetConfiguration,
    Virtual_Com_Port_GetInterface, Virtual_Com_Port_SetInterface,
    Virtual_Com_Port_GetStatus, Virtual_Com_Port_ClearFeature,
    Virtual_Com_Port_SetEndPointFeature, Virtual_Com_Port_SetDeviceFeature,
    Virtual_Com_Port_SetDeviceAddress
};

void Virtual_Com_Port_init(void) {
    pInformation->Current_Configuration = 0;
    PowerOn();
    USB_SIL_Init();
    bDeviceState = UNCONNECTED;
}

void Virtual_Com_Port_Reset(void) {
    pInformation->Current_Configuration = 0;
    pInformation->Current_Feature = 0x80;
    pInformation->Current_Interface = 0;
    SetBTABLE(BTABLE_ADDRESS);
    
    SetEPType(ENDP0, EP_CONTROL);
    SetEPTxStatus(ENDP0, EP_TX_STALL);
    SetEPRxAddr(ENDP0, 0x00); 
    SetEPTxAddr(ENDP0, 0x40); 
    Clear_Status_Out(ENDP0);
    SetEPRxCount(ENDP0, Device_Property.MaxPacketSize);
    SetEPRxValid(ENDP0);

    SetDeviceAddress(0);
    bDeviceState = ATTACHED;
}

void Virtual_Com_Port_SetConfiguration(void) { if (pInformation->Current_Configuration != 0) bDeviceState = CONFIGURED; }
void Virtual_Com_Port_SetDeviceAddress(void) { bDeviceState = ADDRESSED; }
void Virtual_Com_Port_Status_In(void) { if (Request == SET_LINE_CODING) Request = 0; }
void Virtual_Com_Port_Status_Out(void) {}
RESULT Virtual_Com_Port_Data_Setup(uint8_t RequestNo) { return USB_UNSUPPORT; }
RESULT Virtual_Com_Port_NoData_Setup(uint8_t RequestNo) { return USB_UNSUPPORT; }
RESULT Virtual_Com_Port_Get_Interface_Setting(uint8_t Interface, uint8_t AlternateSetting) { return USB_SUCCESS; }
uint8_t *Virtual_Com_Port_GetLineCoding(uint16_t Length) { return NULL; }
uint8_t *Virtual_Com_Port_SetLineCoding(uint16_t Length) { return NULL; }

// 最基础设备描述符 (18字节)
static const uint8_t Hardcoded_Device_Descriptor[18] = {
    0x12, 0x01, 0x00, 0x02, 0x02, 0x00, 0x00, 0x08, 0x09, 0x12, 0x01, 0x00, 0x00, 0x01, 0x01, 0x02, 0x03, 0x01
};
uint8_t *Virtual_Com_Port_GetDeviceDescriptor(uint16_t Length) {
    ONE_DESCRIPTOR desc = { (uint8_t*)Hardcoded_Device_Descriptor, 18 };
    return Standard_GetDescriptorData(Length, &desc);
}

// 最基础配置描述符 (32字节，只包含接口，不包含端点，只为了骗过主机枚举)
static const uint8_t Hardcoded_Config_Descriptor[32] = {
    0x09, 0x02, 0x20, 0x00, 0x01, 0x01, 0x00, 0x80, 0x32, // 配置描述符
    0x09, 0x04, 0x00, 0x00, 0x01, 0x02, 0x02, 0x01, 0x00, // 通信接口
    0x05, 0x24, 0x00, 0x10, 0x01,                         // CDC Header
    0x04, 0x24, 0x02, 0x02,                               // CDC ACM
    0x05, 0x24, 0x06, 0x00, 0x01                          // CDC Union
};
uint8_t *Virtual_Com_Port_GetConfigDescriptor(uint16_t Length) {
    ONE_DESCRIPTOR desc = { (uint8_t*)Hardcoded_Config_Descriptor, 32 };
    return Standard_GetDescriptorData(Length, &desc);
}

uint8_t *Virtual_Com_Port_GetStringDescriptor(uint16_t Length) { return NULL; }