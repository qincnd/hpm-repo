#include "usb_handler.h"
#include "usb_cdc.h"
#include "usb_istr.h"

// ── USB 低优先级中断入口 ──
void USB_LP_CAN1_RX0_IRQHandler(void) {
    USB_Istr();
}

// ── 端点回调（ST 库 usb_istr.c 会调用）──
void EP1_IN_Callback(void)   { /* 中断端点，通常空闲 */ }
void EP2_OUT_Callback(void)  { CDC_EP2_OUT(); }
void EP3_IN_Callback(void)   { CDC_EP3_IN(); }

// ── SET_CONFIGURATION 时由 ST 库调用 ──
void USB_init_endpoints(void) {
    CDC_EP_init();
}

// ── USB 复位回调 ──
void USB_reset_handler(void) {
    CDC_readByteCount = 0;
    CDC_writeBusyFlag = 0;
}
void EP2_IN_Callback(void) { /* NOP */ }
void EP3_OUT_Callback(void) { /* NOP */ }