#pragma once

#include <stdint.h>
#include "stc90c51_reg.h"

void stc90c51_init(void);
