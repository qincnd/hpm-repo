#pragma once
#include "hpm_dev.h"

#define PWM_DUTY_MAX 1000

extern unsigned int pwm_duty_permille;
extern unsigned int pwm_freq_hz;
