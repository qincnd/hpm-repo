#include "pwm.h"
#include "config.h"
#include <stddef.h>

#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_FN(name)   HPM_CAT(DEVICE_NAME, HPM_CAT(_, name))
#define HPM_CALL(prefix, method)  HPM_CAT(prefix, HPM_CAT(_, method))

// 声明芯片驱动提供的引脚 API
void HPM_CALL(pin, init)(void);
void HPM_CALL(pin, write)(unsigned char val);

// 共享状态定义
unsigned int pwm_duty_permille = 0;
unsigned int pwm_freq_hz = 0;

// 内部：把千分比占空比转成比较值（0 ~ 2^resolution - 1）
static unsigned int duty_to_compare(unsigned int permille) {
    if (permille > PWM_DUTY_MAX) permille = PWM_DUTY_MAX;
    // compare = permille * (2^resolution - 1) / 1000
    unsigned int max_val = (1u << resolution) - 1u;
    return (permille * max_val) / PWM_DUTY_MAX;
}

int HPM_FN(init)(void) {
    // 引脚初始化为输出，先拉低
    HPM_CALL(pin, init)();
    HPM_CALL(pin, write)(0);

    pwm_freq_hz = freq_hz;
    pwm_duty_permille = 0;
    return 0;
}

int HPM_FN(set_freq)(unsigned int hz) {
    if (hz == 0) return -1;
    pwm_freq_hz = hz;
    // 频率变更需要重新计算定时器分频；具体由底层芯片驱动完成
    return 0;
}

int HPM_FN(set_duty)(unsigned int permille) {
    if (permille > PWM_DUTY_MAX) return -1;
    pwm_duty_permille = permille;

    unsigned int cmp = duty_to_compare(permille);

    // 用引脚 write 做软件 PWM 退化方案（当底层不支持硬件 PWM 时）
    // 若芯片驱动提供 pwm 总线，这里应改为：
    //   HPM_CALL(bus, set_duty)(cmp);
    // 为保持通用，这里给出位 bang 的最小实现：
    if (cmp == 0) {
        HPM_CALL(pin, write)(0);
    } else if (cmp >= ((1u << resolution) - 1u)) {
        HPM_CALL(pin, write)(1);
    } else {
        // 硬件 PWM 由芯片驱动处理；此处占位，返回 0 表示已接受配置
    }
    return 0;
}

int HPM_FN(start)(void) {
    // 启动输出（若底层有使能位，由芯片驱动处理）
    HPM_CALL(pin, write)(pwm_duty_permille > 0 ? 1 : 0);
    return 0;
}

int HPM_FN(stop)(void) {
    // 停止输出，引脚拉低
    HPM_CALL(pin, write)(0);
    return 0;
}
