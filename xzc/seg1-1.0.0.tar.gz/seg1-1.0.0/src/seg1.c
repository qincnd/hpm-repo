#include "seg1.h"
#include <stddef.h>

#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_FN(name)   HPM_CAT(DEVICE_NAME, HPM_CAT(_, name))
#define HPM_CALL(prefix, method)  HPM_CAT(prefix, HPM_CAT(_, method))

// 声明芯片驱动提供的引脚 API（按 requires 的 key，用能力名展开，不硬编码引脚）
void HPM_CALL(seg_a,  init)(void);
void HPM_CALL(seg_a,  write)(unsigned char level);
void HPM_CALL(seg_b,  init)(void);
void HPM_CALL(seg_b,  write)(unsigned char level);
void HPM_CALL(seg_c,  init)(void);
void HPM_CALL(seg_c,  write)(unsigned char level);
void HPM_CALL(seg_d,  init)(void);
void HPM_CALL(seg_d,  write)(unsigned char level);
void HPM_CALL(seg_e,  init)(void);
void HPM_CALL(seg_e,  write)(unsigned char level);
void HPM_CALL(seg_f,  init)(void);
void HPM_CALL(seg_f,  write)(unsigned char level);
void HPM_CALL(seg_g,  init)(void);
void HPM_CALL(seg_g,  write)(unsigned char level);
void HPM_CALL(seg_dp, init)(void);
void HPM_CALL(seg_dp, write)(unsigned char level);

// 共阳设为 1；共阴设为 0
#ifndef SEG_COMMON_ANODE
#define SEG_COMMON_ANODE 0
#endif

static unsigned char seg1_buf = 0;

static void seg1_write(unsigned char mask)
{
    HPM_CALL(seg_a,  write)((mask >> 0) & 1);
    HPM_CALL(seg_b,  write)((mask >> 1) & 1);
    HPM_CALL(seg_c,  write)((mask >> 2) & 1);
    HPM_CALL(seg_d,  write)((mask >> 3) & 1);
    HPM_CALL(seg_e,  write)((mask >> 4) & 1);
    HPM_CALL(seg_f,  write)((mask >> 5) & 1);
    HPM_CALL(seg_g,  write)((mask >> 6) & 1);
    HPM_CALL(seg_dp, write)((mask >> 7) & 1);
}

int HPM_FN(init)(void)
{
    HPM_CALL(seg_a,  init)();
    HPM_CALL(seg_b,  init)();
    HPM_CALL(seg_c,  init)();
    HPM_CALL(seg_d,  init)();
    HPM_CALL(seg_e,  init)();
    HPM_CALL(seg_f,  init)();
    HPM_CALL(seg_g,  init)();
    HPM_CALL(seg_dp, init)();

    seg1_buf = SEG_COMMON_ANODE ? 0xFF : 0x00;
    seg1_write(seg1_buf);
    return 0;
}

int HPM_FN(set_digit)(unsigned char value)
{
    if (value > 9) return -1;
    unsigned char code = seg1_font[value];
    if (SEG_COMMON_ANODE) code = ~code;
    seg1_buf = code;
    seg1_write(seg1_buf);
    return 0;
}

int HPM_FN(set_raw)(unsigned char seg_mask)
{
    if (SEG_COMMON_ANODE) seg_mask = ~seg_mask;
    seg1_buf = seg_mask;
    seg1_write(seg1_buf);
    return 0;
}

int HPM_FN(set_dp)(unsigned char on)
{
    if (SEG_COMMON_ANODE) {
        if (on) seg1_buf &= ~0x80;
        else    seg1_buf |=  0x80;
    } else {
        if (on) seg1_buf |=  0x80;
        else    seg1_buf &= ~0x80;
    }
    seg1_write(seg1_buf);
    return 0;
}

int HPM_FN(clear)(void)
{
    seg1_buf = SEG_COMMON_ANODE ? 0xFF : 0x00;
    seg1_write(seg1_buf);
    return 0;
}
