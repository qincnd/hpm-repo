#pragma once
#include "hpm_dev.h"

// 段选 GPIO 宏名
#define SEG_A    seg_a
#define SEG_B    seg_b
#define SEG_C    seg_c
#define SEG_D    seg_d
#define SEG_E    seg_e
#define SEG_F    seg_f
#define SEG_G    seg_g
#define SEG_DP   seg_dp

// 共阴数码管 0-9 段码（bit0=a … bit6=g，bit7=dp）
static const unsigned char seg1_font[10] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};
