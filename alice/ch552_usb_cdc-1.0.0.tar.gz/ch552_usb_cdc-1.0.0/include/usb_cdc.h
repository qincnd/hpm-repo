#pragma once
#include <stdint.h>
#include "CH552.H"
#include "usb_descr.h"
#include "usb_handler.h"

// CDC Variables
extern volatile __xdata uint8_t CDC_readByteCount;
extern volatile unsigned char CDC_writeBusyFlag;

// CDC Functions
void CDC_flush(void);
char CDC_read(void);
void CDC_write(char c);
void CDC_print(char* str);
void CDC_println(char* str);

#define CDC_init                  USB_init
#define CDC_available()           (CDC_readByteCount)
#define CDC_ready()               (!CDC_writeBusyFlag)
#define CDC_writeflush(c)         {CDC_write(c);CDC_flush();}

// CDC Control Line State
extern volatile __xdata uint8_t CDC_controlLineState;
#define CDC_DTR_flag    (CDC_controlLineState & 1)
#define CDC_RTS_flag    ((CDC_controlLineState >> 1) & 1)
#define CDC_getDTR()    (CDC_DTR_flag)
#define CDC_getRTS()    (CDC_RTS_flag)

// CDC Line Coding
typedef struct _CDC_LINE_CODING_TYPE {
  uint32_t baudrate;
  uint8_t  stopbits;
  uint8_t  parity;
  uint8_t  databits;
} CDC_LINE_CODING_TYPE, *PCDC_LINE_CODING_TYPE;

extern __xdata CDC_LINE_CODING_TYPE CDC_lineCoding;
#define CDC_getBAUD()   (CDC_lineCoding.baudrate)