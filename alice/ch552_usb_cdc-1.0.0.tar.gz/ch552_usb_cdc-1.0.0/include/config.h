#pragma once

// USB VID/PID（pid.codes 测试用，正式产品需申请）
#define USB_VENDOR_ID       0x1209
#define USB_PRODUCT_ID      0x0001
#define USB_DEVICE_VERSION  0x0100

// 字符串描述符：UTF-16LE，每个字符一个 uint16_t
// 格式：前两个 uint16_t 是 (描述符类型<<8 | 长度) 和语言 ID
// 后面每个 uint16_t 是一个 UTF-16 字符
#define MANUFACTURER_STR_LEN  6
#define MANUFACTURER_STR      'H','P','M'
#define PRODUCT_STR_LEN       16
#define PRODUCT_STR           'C','H','5','5','2',' ','C','D','C'
#define SERIAL_STR_LEN        8
#define SERIAL_STR            '0','0','0','1'
#define INTERFACE_STR_LEN     8
#define INTERFACE_STR         'C','D','C'

// USB 最大电流（mA）
#define USB_MAX_POWER_mA    100