// ===================================================================================
// USB Descriptors for CH552
// ===================================================================================
#include "usb_descr.h"
#define HPM_GEN_STRINGS 1
#include "config.h"
// ===================================================================================
// EP Buffer 定义
// ===================================================================================
__xdata __at (EP0_ADDR) uint8_t EP0_buffer[EP0_BUF_SIZE];
__xdata __at (EP1_ADDR) uint8_t EP1_buffer[EP1_BUF_SIZE];
__xdata __at (EP2_ADDR) uint8_t EP2_buffer[EP2_BUF_SIZE];

// ===================================================================================
// Device Descriptor
// ===================================================================================
__code USB_DEV_DESCR DevDescr = {
    .bLength            = sizeof(DevDescr),
    .bDescriptorType    = USB_DESCR_TYP_DEVICE,
    .bcdUSBL            = 0x10,
    .bcdUSBH            = 0x01,
    .bDeviceClass       = 0,
    .bDeviceSubClass    = 0,
    .bDeviceProtocol    = 0,
    .bMaxPacketSize0    = EP0_SIZE,
    .idVendorL          = usb_vid & 0xFF,
    .idVendorH          = (usb_vid >> 8) & 0xFF,
    .idProductL         = usb_pid & 0xFF,
    .idProductH         = (usb_pid >> 8) & 0xFF,
    .bcdDeviceL         = usb_device_version & 0xFF,
    .bcdDeviceH         = (usb_device_version >> 8) & 0xFF,
    .iManufacturer      = 1,
    .iProduct           = 2,
    .iSerialNumber      = 3,
    .bNumConfigurations = 1
};

// ===================================================================================
// Configuration Descriptor
// ===================================================================================
__code USB_CFG_DESCR_CDC CfgDescr = {
    .config = {
        .bLength            = sizeof(USB_CFG_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_CONFIG,
        .wTotalLengthL      = sizeof(CfgDescr) & 0xFF,
        .wTotalLengthH      = (sizeof(CfgDescr) >> 8) & 0xFF,
        .bNumInterfaces     = 2,
        .bConfigurationValue= 1,
        .iConfiguration     = 0,
        .bmAttributes       = 0x80,
        .MaxPower           = usb_max_power_ma / 2
    },
    .association = {
        .bLength            = sizeof(USB_IAD_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_IAD,
        .bFirstInterface    = 0,
        .bInterfaceCount    = 2,
        .bFunctionClass     = USB_DEV_CLASS_COMM,
        .bFunctionSubClass  = 2,
        .bFunctionProtocol  = 1,
        .iFunction          = 4
    },
    .interface0 = {
        .bLength            = sizeof(USB_ITF_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_INTERF,
        .bInterfaceNumber   = 0,
        .bAlternateSetting  = 0,
        .bNumEndpoints      = 1,
        .bInterfaceClass    = USB_DEV_CLASS_COMM,
        .bInterfaceSubClass = 2,
        .bInterfaceProtocol = 1,
        .iInterface         = 4
    },
    .functional = {
        0x05,0x24,0x00,0x10,0x01,
        0x05,0x24,0x01,0x00,0x00,
        0x04,0x24,0x02,0x02,
        0x05,0x24,0x06,0x00,0x01
    },
    .ep1IN = {
        .bLength            = sizeof(USB_ENDP_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_ENDP,
        .bEndpointAddress   = USB_ENDP_ADDR_EP1_IN,
        .bmAttributes       = USB_ENDP_TYPE_INTER,
        .wMaxPacketSizeL    = EP1_SIZE & 0xFF,
        .wMaxPacketSizeH    = (EP1_SIZE >> 8) & 0xFF,
        .bInterval          = 1
    },
    .interface1 = {
        .bLength            = sizeof(USB_ITF_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_INTERF,
        .bInterfaceNumber   = 1,
        .bAlternateSetting  = 0,
        .bNumEndpoints      = 2,
        .bInterfaceClass    = USB_DEV_CLASS_DATA,
        .bInterfaceSubClass = 0,
        .bInterfaceProtocol = 0,
        .iInterface         = 4
    },
    .ep2OUT = {
        .bLength            = sizeof(USB_ENDP_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_ENDP,
        .bEndpointAddress   = USB_ENDP_ADDR_EP2_OUT,
        .bmAttributes       = USB_ENDP_TYPE_BULK,
        .wMaxPacketSizeL    = EP2_SIZE & 0xFF,
        .wMaxPacketSizeH    = (EP2_SIZE >> 8) & 0xFF,
        .bInterval          = 0
    },
    .ep2IN = {
        .bLength            = sizeof(USB_ENDP_DESCR),
        .bDescriptorType    = USB_DESCR_TYP_ENDP,
        .bEndpointAddress   = USB_ENDP_ADDR_EP2_IN,
        .bmAttributes       = USB_ENDP_TYPE_BULK,
        .wMaxPacketSizeL    = EP2_SIZE & 0xFF,
        .wMaxPacketSizeH    = (EP2_SIZE >> 8) & 0xFF,
        .bInterval          = 0
    }
};

// ===================================================================================
// String Descriptors
// ===================================================================================

__code uint16_t LangDescr[] = {
    ((uint16_t)USB_DESCR_TYP_STRING << 8) | sizeof(LangDescr), 0x0409
};

#ifdef HPM_USB_STRINGS_DEFINED
// config.h 已生成 ManufDescr、ProdDescr、SerDescr、InterfDescr
#else
// 默认值（固定长度，硬编码）
__code uint16_t ManufDescr[] = {
    (USB_DESCR_TYP_STRING << 8) | (2 + 16 * 2),
    'H', 'P', 'M', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '
};
__code uint16_t ProdDescr[] = {
    (USB_DESCR_TYP_STRING << 8) | (2 + 16 * 2),
    'C', 'H', '5', '5', '2', ' ', 'C', 'D', 'C', ' ', ' ', ' ', ' ', ' ', ' ', ' '
};
__code uint16_t SerDescr[] = {
    (USB_DESCR_TYP_STRING << 8) | (2 + 64 * 2),
    '0', '0', '0', '1', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '
};
__code uint16_t InterfDescr[] = {
    (USB_DESCR_TYP_STRING << 8) | (2 + 16 * 2),
    'C', 'D', 'C', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '
};
#endif