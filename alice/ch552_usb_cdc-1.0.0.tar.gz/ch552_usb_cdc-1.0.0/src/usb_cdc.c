// ===================================================================================
// Basic USB CDC Functions for CH552
// ===================================================================================

#include "usb_cdc.h"

// ===================================================================================
// Variables and Defines
// ===================================================================================

__xdata CDC_LINE_CODING_TYPE CDC_lineCoding = {
  .baudrate = 115200,
  .stopbits = 0,
  .parity   = 0,
  .databits = 8
};

volatile __xdata uint8_t CDC_controlLineState = 0;
volatile __xdata uint8_t CDC_readByteCount = 0;
volatile __xdata uint8_t CDC_readPointer   = 0;
volatile __xdata uint8_t CDC_writePointer  = 0;
volatile unsigned char CDC_writeBusyFlag = 0;

// CDC class requests
#define SET_LINE_CODING         0x20
#define GET_LINE_CODING         0x21
#define SET_CONTROL_LINE_STATE  0x22
#define SEND_BREAK              0x23

// ===================================================================================
// Front End Functions
// ===================================================================================

void CDC_flush(void) {
  if(!CDC_writeBusyFlag && CDC_writePointer) {
    CDC_writeBusyFlag = 1;
    UEP2_T_LEN = CDC_writePointer;
    UEP2_CTRL  = (UEP2_CTRL & ~MASK_UEP_T_RES) | UEP_T_RES_ACK;
    CDC_writePointer = 0;
  }
}

void CDC_write(char c) {
  while(CDC_writeBusyFlag);
  EP2_buffer[64 + CDC_writePointer++] = c;
  if(CDC_writePointer == EP2_SIZE) CDC_flush();
}

void CDC_print(char* str) {
  while(*str) CDC_write(*str++);
}

void CDC_println(char* str) {
  CDC_print(str);
  CDC_write('\n');
  CDC_flush();
}

char CDC_read(void) {
  char data;
  while(!CDC_readByteCount);
  data = EP2_buffer[CDC_readPointer++];
  if(--CDC_readByteCount == 0)
    UEP2_CTRL = (UEP2_CTRL & ~MASK_UEP_R_RES) | UEP_R_RES_ACK;
  return data;
}

// ===================================================================================
// CDC-Specific USB Handler Functions
// ===================================================================================

void CDC_EP_init(void) {
  // CH552：16 位 SFR
  UEP1_DMA = (uint16_t)EP1_buffer;
  UEP2_DMA = (uint16_t)EP2_buffer;

  UEP1_CTRL   = bUEP_AUTO_TOG | UEP_T_RES_NAK;
  UEP2_CTRL   = bUEP_AUTO_TOG | UEP_T_RES_NAK | UEP_R_RES_ACK;
  UEP2_3_MOD  = bUEP2_RX_EN | bUEP2_TX_EN;
  UEP4_1_MOD  = bUEP1_TX_EN;
  UEP1_T_LEN  = 0;
  UEP2_T_LEN  = 0;
  CDC_readByteCount = 0;
  CDC_writeBusyFlag = 0;
}

uint8_t CDC_control(void) {
  uint8_t i;
  switch(USB_SetupReq) {
    case GET_LINE_CODING:
      for(i=0; i<sizeof(CDC_lineCoding); i++)
        EP0_buffer[i] = ((uint8_t*)&CDC_lineCoding)[i];
      return sizeof(CDC_lineCoding);
    case SET_CONTROL_LINE_STATE:
      CDC_controlLineState = EP0_buffer[2];
      return 0;
    case SET_LINE_CODING:
      return 0;
    default:
      return 0xff;
  }
}

void CDC_EP0_OUT(void) {
  uint8_t i;
  if(USB_SetupReq == SET_LINE_CODING) {
    for(i=0; i<((sizeof(CDC_lineCoding)<=USB_RX_LEN)?sizeof(CDC_lineCoding):USB_RX_LEN); i++)
      ((uint8_t*)&CDC_lineCoding)[i] = EP0_buffer[i];
  }
  UEP0_CTRL = bUEP_T_TOG | UEP_T_RES_ACK | UEP_R_RES_ACK;
}

void CDC_EP2_IN(void) {
  UEP2_CTRL  = (UEP2_CTRL & ~MASK_UEP_T_RES) | UEP_T_RES_NAK;
  CDC_writeBusyFlag = 0;
}

void CDC_EP2_OUT(void) {
  if(U_TOG_OK && USB_RX_LEN) {
    UEP2_CTRL = (UEP2_CTRL & ~MASK_UEP_R_RES) | UEP_R_RES_NAK;
    CDC_readByteCount = USB_RX_LEN;
    CDC_readPointer   = 0;
  }
}