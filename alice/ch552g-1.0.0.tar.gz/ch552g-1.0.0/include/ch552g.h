#pragma once

#include <stdint.h>
#include "CH552.H"

static inline void ch552g_clock_24m(void) {
    SAFE_MOD = 0x55;
    SAFE_MOD = 0xAA;
    CLOCK_CFG = (CLOCK_CFG & ~MASK_SYS_CK_SEL) | 0x06;
    SAFE_MOD = 0x00;
}

void ch552g_init(void);