#pragma once

#include <stdint.h>

void hpm_pin_P1_1_init(void);
void hpm_pin_P1_1_write(int level);
int  hpm_pin_P1_1_read(void);

void hpm_pin_P1_4_init(void);
void hpm_pin_P1_4_write(int level);
int  hpm_pin_P1_4_read(void);

void hpm_pin_P1_5_init(void);
void hpm_pin_P1_5_write(int level);
int  hpm_pin_P1_5_read(void);

void hpm_pin_P3_0_init(void);
void hpm_pin_P3_0_write(int level);
int  hpm_pin_P3_0_read(void);

void hpm_pin_P3_1_init(void);
void hpm_pin_P3_1_write(int level);
int  hpm_pin_P3_1_read(void);

void hpm_pin_P3_2_init(void);
void hpm_pin_P3_2_write(int level);
int  hpm_pin_P3_2_read(void);

void hpm_pin_P3_3_init(void);
void hpm_pin_P3_3_write(int level);
int  hpm_pin_P3_3_read(void);

void hpm_pin_P3_4_init(void);
void hpm_pin_P3_4_write(int level);
int  hpm_pin_P3_4_read(void);